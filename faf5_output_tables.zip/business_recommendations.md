# Business Recommendations
1. **Prioritise regional and metro truck capacity.** Trucks carry 64% of tons, 88% of domestic tons move under 500 miles and 56% stay within one zone. Focus first on intra-regional distribution, drayage and terminal access.
2. **Plan around the gateways.** The top 3 import entry regions handle 29% of import value; run gateway-level capacity and resilience reviews there.
3. **Segment by value density, not tonnage alone.** Protect reliability and speed for the 18 commodities that make up 80% of value (e.g. Electronics, Motorized vehicles, Pharmaceuticals); manage bulk commodities such as Natural gas and other fossil products on cost and volume.
4. **Build shock resilience.** The 2020 drop (4.6% in tons, 5.6% in ton-miles) shows exposure; keep flexible capacity and alternative modes.
5. **Watch sourcing shifts.** Imports from SE Asia & Oceania grew 7.2%/yr; check whether gateway and corridor plans match the changing origins.
6. **Use the 2050 outlook as a scenario.** Trucks absorb 73% of the extra tons; test infrastructure and fleet plans against this and refresh when FAF updates.
7. **Close data gaps before committing capital.** Add costs, congestion, shipment-level data and monthly volumes.