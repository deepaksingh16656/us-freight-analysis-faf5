# Insights Report: U.S. Freight (FAF5 v5.7.1)
1. **Scale and trend.** Freight reached 20,012 million tons and $18,991 billion (2017 USD) in 2024. Since 2017 it has been essentially flat: tons +0.16%/yr, value +0.06%/yr, ton-miles -0.14%/yr (ton-miles are -1.0% vs 2017).
2. **2020 shock.** Versus 2019, tons fell 4.6%, value 4.8% and ton-miles 5.6%. Ton-miles fell the most, so average hauls shortened. By 2024 tonnage is -0.3% vs 2019, but ton-miles are -1.6%.
3. **Trade mix.** Domestic flows are 88% of tons and 79% of value; imports 5% of tons but 13% of value; exports 6% / 8%. Imports are worth about $2,229 per ton versus $848 domestically.
4. **Modes.** Truck carries 64% of tons and 72% of value (average haul 187 miles). Pipeline carries 20% of tons but 6% of value. Air carries 0.03% of tons but 3.4% of value.
5. **Volume is not value.** Natural gas and other fossil products leads tonnage while Electronics leads value. The top 10 commodities hold 61% of value and 18 of 42 commodities make up 80%.
6. **Local and short-haul dominates.** 88% of domestic tons move under 500 miles and 56% stay inside a single FAF zone. The top 100 zone pairs carry 54% of domestic tons (89 of them are within-zone flows). Largest corridors between different zones: Rest of TX  ->  Houston TX; Rest of TX  ->  New Orleans LA-MS (LA Part); Mississippi  ->  Rest of AL.
7. **Geography.** Texas ships 14% of domestic tons (within-state flows included). The top 3 import entry regions handle 29% of import value.
8. **Foreign trade.** Goods flows show an import surplus of $879 billion in 2024 (2017 USD). Imports from SE Asia & Oceania grew 7.2%/yr since 2017, while imports from Eastern Asia changed -2.0%/yr.
9. **Outlook to 2050 (baseline).** Tons rise 44% to 28,890 Mt (+1.42%/yr) and value 91% to $36,283 bn (+2.52%/yr), so the mix shifts toward higher-value goods. Truck absorbs 73% of added tons; Multiple modes & mail grows fastest among larger modes; biggest tonnage additions: Natural gas and other fossil products, Gravel, Basic chemicals.
10. **Portfolio.** 14 'high-value growth' commodities hold 53% of 2024 value and deliver 72% of the value added by 2050.
